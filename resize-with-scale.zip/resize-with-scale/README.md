# Resize with Scale

A Pen created on CodePen.io. Original URL: [https://codepen.io/chriscoyier/pen/VvRoWy](https://codepen.io/chriscoyier/pen/VvRoWy).

